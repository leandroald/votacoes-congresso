// src/lib/api-camara.ts
const BASE = "https://dadosabertos.camara.leg.br/api/v2";

export type Deputado = {
  id: number;
  nome: string;
  siglaPartido: string;
  siglaUf: string;
  urlFoto: string;
};

export async function buscarDeputados(nome?: string): Promise<Deputado[]> {
  const url = new URL(`${BASE}/deputados`);
  if (nome && nome.trim()) url.searchParams.set("nome", nome.trim());
  url.searchParams.set("itens", "50");

  const r = await fetch(url.toString());
  if (!r.ok) throw new Error("Falha ao buscar deputados");

  const j = await r.json();
  return (j.dados || []).map((d: any) => ({
    id: d.id,
    nome: d.nome,
    siglaPartido: d.siglaPartido,
    siglaUf: d.siglaUf,
    urlFoto: d.urlFoto,
  }));
}

export async function buscarDeputado(id: string | number): Promise<Deputado> {
  const r = await fetch(`${BASE}/deputados/${id}`);
  if (!r.ok) throw new Error("Falha ao buscar deputado");

  const j = await r.json();
  const d = j.dados || {};
  return {
    id: d.id,
    nome: d.ultimoStatus?.nomeEleitoral || d.nomeCivil || "Deputado",
    siglaPartido: d.ultimoStatus?.siglaPartido || "",
    siglaUf: d.ultimoStatus?.siglaUf || "",
    urlFoto: d.ultimoStatus?.urlFoto || "",
  };
}

export type VotoDeputado = {
  idVotacao: string;
  descricao: string;
  data: string; // YYYY-MM-DD
  hora: string; // HH:MM
  voto: string; // Sim/Não/Abstenção/Obstrução/etc.
};

export async function buscarUltimasVotacoesDoDeputado(
  id: string | number,
  limite = 20
): Promise<VotoDeputado[]> {
  const url = new URL(`${BASE}/deputados/${id}/votacoes`);
  url.searchParams.set("itens", String(limite));

  const r = await fetch(url.toString());
  if (!r.ok) throw new Error("Falha ao buscar votações do deputado");

  const j = await r.json();
  return (j.dados || []).map((v: any) => ({
    idVotacao: String(v.idVotacao),
    descricao: v.descricao || v.titulo || "Votação",
    data: v.data,
    hora: v.hora || "00:00",
    voto: v.voto || v.siglaVoto || "",
  }));
}

