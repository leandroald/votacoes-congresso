import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, Users, FileText, TrendingUp } from "lucide-react";
import { useLocation } from "wouter";

export default function Home() {
  const [searchTerm, setSearchTerm] = useState("");
  const [, navigate] = useLocation();

  const handleSearch = () => {
    if (searchTerm.trim()) {
      navigate(`/deputados?nome=${encodeURIComponent(searchTerm)}`);
    } else {
      navigate("/deputados");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
              <FileText className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Votações do Congresso</h1>
              <p className="text-xs text-muted-foreground">Transparência Legislativa</p>
            </div>
          </div>
        </div>
      </header>

      <section className="bg-gradient-to-br from-primary/5 via-accent/5 to-background py-16">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4" variant="secondary">
                Dados Abertos do Congresso Nacional
              </Badge>
              <h2 className="text-4xl font-bold mb-6">
                Acompanhe como seus representantes votam
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Consulte o histórico de votações de deputados e senadores.
              </p>
              
              <Card>
                <CardHeader>
                  <CardTitle>Buscar Parlamentar</CardTitle>
                  <CardDescription>Digite o nome do deputado</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Ex: João Silva..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        onKeyPress={handleKeyPress}
                        className="pl-10"
                      />
                    </div>
                    <Button onClick={handleSearch}>Buscar</Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-4">
              <Card className="border-l-4 border-l-primary">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Deputados Federais
                    </CardTitle>
                    <Users className="h-4 w-4 text-primary" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">513</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Representantes na Câmara
                  </p>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-l-accent">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Senadores
                    </CardTitle>
                    <Users className="h-4 w-4 text-accent" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">81</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Representantes no Senado
                  </p>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-l-blue-500">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Votações Registradas
                    </CardTitle>
                    <TrendingUp className="h-4 w-4 text-blue-500" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">5.000+</div>
                  <p className="text-xs text-muted-foreground mt-1">Desde 2023</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t py-8 mt-auto">
        <div className="container">
          <p className="text-sm text-muted-foreground text-center">
            Dados fornecidos pelas APIs oficiais da Câmara dos Deputados e Senado Federal
          </p>
        </div>
      </footer>
    </div>
  );
}

