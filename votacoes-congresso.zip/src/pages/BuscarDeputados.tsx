import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, ArrowLeft } from "lucide-react";
import { buscarDeputados, type Deputado } from "@/lib/api-camara";

export default function BuscarDeputados() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1]);
  const nomeInicial = searchParams.get('nome') || '';
  const [searchTerm, setSearchTerm] = useState(nomeInicial);
  const [deputados, setDeputados] = useState<Deputado[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    carregarDeputados(nomeInicial);
  }, []);

  const carregarDeputados = async (nome?: string) => {
    setLoading(true);
    setError(null);
    try {
      const dados = await buscarDeputados(nome);
      setDeputados(dados);
    } catch (err) {
      setError('Erro ao carregar deputados');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    carregarDeputados(searchTerm);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Voltar
            </Button>
          </Link>
        </div>
      </header>
      <main className="container py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Buscar Deputados</h1>
          <Card className="mb-8">
            <div className="p-6">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4" />
                  <Input
                    placeholder="Digite o nome..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button onClick={handleSearch}>Buscar</Button>
              </div>
            </div>
          </Card>

          {loading && (
            <div className="grid md:grid-cols-2 gap-4">
              {[1,2,3,4].map(i => (
                <Card key={i}>
                  <div className="p-6"><Skeleton className="h-16 w-full" /></div>
                </Card>
              ))}
            </div>
          )}

          {error && (
            <Card>
              <div className="p-6">
                <p className="text-destructive">{error}</p>
              </div>
            </Card>
          )}

          {!loading && !error && deputados.length === 0 && (
            <Card><div className="p-6 text-center"><p>Nenhum deputado encontrado</p></div></Card>
          )}

          {!loading && !error && deputados.length > 0 && (
            <div className="grid md:grid-cols-2 gap-4">
              {deputados.map(d => (
                <Link key={d.id} href={`/deputado/${d.id}`}>
                  <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                    <div className="p-6 flex gap-4">
                      <img src={d.urlFoto} alt={d.nome} className="h-16 w-16 rounded-full" />
                      <div className="flex-1">
                        <h3 className="font-semibold mb-1">{d.nome}</h3>
                        <div className="flex gap-2">
                          <Badge variant="secondary">{d.siglaPartido}</Badge>
                          <Badge variant="outline">{d.siglaUf}</Badge>
                        </div>
                      </div>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
