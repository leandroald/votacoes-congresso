#!/usr/bin/env bash
set -euo pipefail

# ============================
# Configurações do projeto
# ============================
APP_NAME="votacoes-congresso"
# Pode sobrescrever via env: REGION=sa-east-1 bash deploy.sh
REGION="${REGION:-sa-east-1}"       # mantém na sua região (São Paulo). Use us-east-1 se preferir.
DIST_DIR="dist"                     # pasta gerada pelo npm run build
PRICE_CLASS="PriceClass_100"        # NA+EU (barato). Troque p/ PriceClass_All se quiser global.

# ============================
# Pré-checagens
# ============================
command -v aws >/dev/null || { echo "❌ aws cli não encontrado"; exit 1; }
command -v jq  >/dev/null || { echo "❌ jq não encontrado (sudo apt-get install jq)"; exit 1; }

ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"
BUCKET="${APP_NAME}-site-${ACCOUNT_ID}"   # único globalmente
COMMENT="${APP_NAME} - ${USER}@$(hostname)"

echo "▶️ Região ativa do CLI: $(aws configure get region || echo 'NÃO DEFINIDA')"
echo "▶️ Região alvo do deploy: ${REGION}"
echo "▶️ Conta AWS: ${ACCOUNT_ID}"
echo "▶️ Bucket: ${BUCKET}"

# ============================
# 1) Build do frontend
# ============================
if [ -f package.json ]; then
  echo "🧱 Buildando frontend..."
  (npm ci || npm install)
  npm run build
else
  echo "⚠️ package.json não encontrado. Pulando build."
fi

test -d "${DIST_DIR}" || { echo "❌ pasta ${DIST_DIR} não existe. Rode npm run build"; exit 1; }

# ============================
# 2) S3 - criar bucket (se não existir) + site estático
# ============================
echo "🪣 Conferindo bucket s3://${BUCKET}..."
if ! aws s3api head-bucket --bucket "${BUCKET}" 2>/dev/null; then
  echo "🪣 Criando bucket em ${REGION}..."
  if [ "${REGION}" = "us-east-1" ]; then
    aws s3api create-bucket --bucket "${BUCKET}" --region us-east-1
  else
    aws s3api create-bucket \
      --bucket "${BUCKET}" \
      --region "${REGION}" \
      --create-bucket-configuration LocationConstraint="${REGION}"
  fi
else
  echo "♻️ Bucket já existe, seguindo..."
fi

echo "🔓 Desativando Public Access Block do bucket..."
aws s3api put-public-access-block --bucket "${BUCKET}" --public-access-block-configuration \
'{"BlockPublicAcls":false,"IgnorePublicAcls":false,"BlockPublicPolicy":false,"RestrictPublicBuckets":false}'

echo "🌐 Habilitando website hosting no S3..."
aws s3 website "s3://${BUCKET}" --index-document index.html --error-document index.html

echo "📝 Aplicando bucket policy pública (somente leitura aos objetos)..."
POLICY=$(cat <<JSON
{
  "Version": "2012-10-17",
  "Statement": [{
    "Sid": "PublicReadGetObject",
    "Effect": "Allow",
    "Principal": "*",
    "Action": "s3:GetObject",
    "Resource": "arn:aws:s3:::${BUCKET}/*"
  }]
}
JSON
)
aws s3api put-bucket-policy --bucket "${BUCKET}" --policy "${POLICY}"

echo "🚚 Publicando arquivos para s3://${BUCKET}..."
aws s3 sync "${DIST_DIR}/" "s3://${BUCKET}/" --delete

S3_WEBSITE_DOMAIN="${BUCKET}.s3-website-${REGION}.amazonaws.com"
echo "✅ Site (HTTP) via S3:  http://${S3_WEBSITE_DOMAIN}"

# ============================
# 3) CloudFront - criar (ou reaproveitar) distribuição HTTPS (SPA friendly)
# ============================
echo "🧭 Procurando distribuição CloudFront existente para essa origem..."
DIST_ID="$(aws cloudfront list-distributions \
  --query "DistributionList.Items[?Origins.Items[?DomainName=='${S3_WEBSITE_DOMAIN}']].Id | [0]" \
  --output text 2>/dev/null || true)"

if [ "${DIST_ID}" = "None" ] || [ -z "${DIST_ID}" ]; then
  echo "🆕 Criando distribuição CloudFront..."
  CF_CONFIG=$(cat <<JSON
{
  "CallerReference": "${APP_NAME}-$(date +%s)",
  "Comment": "${COMMENT}",
  "Aliases": { "Quantity": 0 },
  "DefaultRootObject": "index.html",
  "Origins": {
    "Quantity": 1,
    "Items": [{
      "Id": "s3-website-origin",
      "DomainName": "${S3_WEBSITE_DOMAIN}",
      "CustomOriginConfig": {
        "HTTPPort": 80,
        "HTTPSPort": 443,
        "OriginProtocolPolicy": "http-only",
        "OriginSslProtocols": { "Quantity": 1, "Items": ["TLSv1.2"] }
      }
    }]
  },
  "DefaultCacheBehavior": {
    "TargetOriginId": "s3-website-origin",
    "ViewerProtocolPolicy": "redirect-to-https",
    "AllowedMethods": { "Quantity": 2, "Items": ["GET","HEAD"] },
    "MinTTL": 0,
    "DefaultTTL": 86400,
    "MaxTTL": 31536000
  },
  "CustomErrorResponses": {
    "Quantity": 2,
    "Items": [
      { "ErrorCode": 403, "ResponsePagePath": "/index.html", "ResponseCode": "200", "ErrorCachingMinTTL": 0 },
      { "ErrorCode": 404, "ResponsePagePath": "/index.html", "ResponseCode": "200", "ErrorCachingMinTTL": 0 }
    ]
  },
  "PriceClass": "${PRICE_CLASS}",
  "Enabled": true,
  "ViewerCertificate": { "CloudFrontDefaultCertificate": true },
  "HttpVersion": "http2",
  "IsIPV6Enabled": true
}
JSON
)
  CREATE_OUT="$(aws cloudfront create-distribution --distribution-config "${CF_CONFIG}")"
  DIST_ID="$(echo "${CREATE_OUT}" | jq -r '.Distribution.Id')"
  CF_DOMAIN="$(echo "${CREATE_OUT}" | jq -r '.Distribution.DomainName')"
  echo "🕒 Aguardando status Deployed..."
  aws cloudfront wait distribution-deployed --id "${DIST_ID}"
else
  echo "♻️ Usando distribuição existente: ${DIST_ID}"
  CF_DOMAIN="$(aws cloudfront get-distribution --id "${DIST_ID}" --query 'Distribution.DomainName' --output text)"
fi

echo "✅ CloudFront (HTTPS): https://${CF_DOMAIN}"

# ============================
# 4) Invalidação de cache
# ============================
echo "🧹 Invalidando cache do CloudFront..."
aws cloudfront create-invalidation --distribution-id "${DIST_ID}" --paths "/*" >/dev/null

echo
echo "🎉 Deploy concluído!"
echo "➡️  HTTP (S3):  http://${S3_WEBSITE_DOMAIN}"
echo "➡️  HTTPS (CF): https://${CF_DOMAIN}"

